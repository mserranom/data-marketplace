from chalice import Chalice, CognitoUserPoolAuthorizer
import boto3
import json

from backend.config_validator import validate

client = boto3.client('lambda')

app = Chalice(app_name='data-marketplace-backend')

authorizer = CognitoUserPoolAuthorizer(
    'MyPool', provider_arns=['arn:aws:cognito-idp:us-west-2:280996535957:userpool/us-west-2_CoIS7kwaJ'])

@app.route('/users/me', methods=['GET'], authorizer=authorizer, cors=True)
def me():
    return(app.current_request.to_dict())


# curl --header "Content-Type: application/json" --request POST --data '{"id":"malaga_autobuses","name":"ubicacion", "url":"http://datosabiertos.malaga.eu/recursos/transporte/EMT/EMTLineasUbicaciones/lineasyubicaciones.csv"}' http://localhost:8000/config

@app.route('/config', methods=['POST'])
def upsert_config():
    config = app.current_request.json_body
    config_validation = validate(config)
    if config_validation['success']:
        data = config_validation["data"]
        return add_subscription(data["url"], data["interval"])
    else:
        return config_validation['error_message']


def add_subscription(url, interval):
    # https://docs.aws.amazon.com/lambda/latest/dg/API_Invoke.html
    payload = {"url":url, "interval":interval}
    response = client.invoke(
        FunctionName='poller_add_subscription',
        LogType='Tail',
        Payload=json.dumps(payload)
    )
    # print(response)
    return response["StatusCode"]
